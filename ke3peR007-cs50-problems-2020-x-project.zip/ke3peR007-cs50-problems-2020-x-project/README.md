As we know everything is now being online from booking movies tickets to purchasing vegetables.
So I have made E-commerce website through which we can do online shopping of watches.


This project is made from below technologies:
1. Flask
2. sqlite
3. Jinja
4. html/css
5. Javscript

All the data is store in database including images.
On the index page data is fetched from db.

There are two types of login:
1. admin login
2. user login

Privilege for admin login are:
1. Admin user can add/edit/delete product from db.
2. Admin user can add/edit/delete user from db.

Privilege for user login are:
1. User can buy a paticular item.
2. User can also see their history of purchases.
3. User can also change their password.