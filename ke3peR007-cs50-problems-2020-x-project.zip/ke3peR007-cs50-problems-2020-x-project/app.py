from cs50 import SQL
from flask import Flask, redirect, render_template, request, session
from flask_session import Session
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash
from tempfile import mkdtemp
import sqlite3
from flask_sqlalchemy import SQLAlchemy
from PIL import Image
from io import BytesIO
from base64 import b64encode

from helpers import apology, login_required

app = Flask(__name__)

@app.after_request
def after_request(response):
  response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
  response.headers["Expires"] = 0
  response.headers["Pragma"] = "no-cache"
  return response

app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
# app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///ecomm.db"
Session(app)

# db = SQLAlchemy(app)
db = SQL("sqlite:///ecomm.db")
@app.route("/")
def index():
    product_info = db.execute("SELECT id, pname, pimage FROM PRODUCT")
    product = db.execute("SELECT id from product")
    
    images = []
    # size = []
    # names = []
    count = 0
    for lst in product_info:
        
        for key, value in lst.items():
            images.append({})
            if key == 'pimage':
                images[count]['pimage'] = b64encode(value).decode("utf-8")
            elif key == 'id':
                images[count]['id'] = value
            else:
                continue
        count += 1  
    
    return render_template("index.html",product_info=product_info,images=images,product=product)

@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE uname = :username",
                          username=request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]
        session["username"] = rows[0]["uname"]
        session["is_admin"] = rows[0]["is_admin"]
        # session["cart_items"] = rows[0]["cart_items"]
        # print(session["cart_items"])
        # Redirect user to home page
        print(session["is_admin"])
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""
    if request.method == "GET":
        return render_template("register.html")
    else:
        username = request.form.get("username")
        if not username:
            return render_template("apology.html", message="You must enter a Username")
        else:
            output = db.execute("SELECT id FROM users where uname=?", username)
            print(type(output))
            if (len(output) != 0 ):
                return render_template("apology.html", message="Username already exists")
        firstname = request.form.get("firstname")
        lastname = request.form.get("lastname")
        email = request.form.get("email")
        password = request.form.get("password")
        confirmation = request.form.get("confirmation")
        email = request.form.get("email")
        if not firstname:
          return render_template("apology.html", message="You must enter First Name")
        if not lastname:
          return render_template("apology.html", message="You must enter Last Name")
        if not email:
            return render_template("apology.html", message="You must enter a Email address")
        else:
            output = db.execute("SELECT id FROM users where uemail=?", email)
            print(type(output))
            if (len(output) != 0 ):
                return render_template("apology.html", message="Email already exists")
        password = request.form.get("password")
        if not password:
            return render_template("apology.html", message="You must enter a Password")
        confirmation = request.form.get("confirmation")
        if not confirmation:
            return render_template("apology.html", message="You must re-enter  Password")
        if password != confirmation:
            return render_template("apology.html", message="Your passwoed does not match")
        else:
            hash_password = generate_password_hash(password, method='pbkdf2:sha256', salt_length=8)
            print(hash_password)
            db.execute("INSERT INTO users (uname, ufirst, ulast , uemail, hash) VALUES (:uname, :ufirst, :ulast, :uemail, :hashvalue)", uname=username, ufirst=firstname, ulast=lastname, uemail=email, hashvalue=hash_password)
            return render_template("index.html",message="success register")

@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return render_template("index.html", message="logout success")

@app.route("/admin_settings", methods=["GET", "POST"])
@login_required
def admin_settings():
    if request.method == "GET":
        product_data = db.execute("SELECT pname, pimage FROM product")
        product_other_data = db.execute("SELECT * FROM product")
        print("inside admin settings get")
        print(type(product_data))
        # print(product_data)
        # with open('abc.png', 'wb') as q:

        #      q.write(product_data[0]['pimage'])
        # images = []
        # for i in range(len(product_data)):
        #     images.append(b64encode(product_data[i]['pimage']).decode("utf-8"))
        return render_template("admin_settings_product.html", product_data=product_data, product_other_data=product_other_data)
    else:
        
        print("inside admin settings get")
        pname = request.form.get("product_name")
        pprice = request.form.get("product_price")
        pimage = request.files["product_image"]
        pdescription = request.form.get("product_description")
        print(pname)
        print(pprice)
        print(type(pimage))
        print(pimage.filename)
        print(pdescription)
        if not pname:
            return render_template("apology.html", message="must enter product name")
        elif not pprice:
            return render_template("apology.html", message="must enter product price")
        elif not pimage:
            return render_template("apology.html", message="must upload product image")
        elif not pdescription:
            return render_template("apology.html", message="must enter product desciprtion")
        else:
            db.execute("INSERT INTO product (pname, pprice, pimage , pdescription) VALUES (:pname, :pprice, :pimage, :pdescription)", pname=pname, pprice=pprice, pimage=pimage.read(), pdescription=pdescription)
            return redirect("/admin_settings")

@app.route("/admin_settings_user", methods=["GET", "POST"])
@login_required
def admin_settings_user():
    if request.method == "GET":
        user_details = db.execute("SELECT id, uname, ufirst, ulast, uemail, is_admin FROM users")
        return render_template("admin_settings_user.html", user_details=user_details)
    else:
        pass

@app.route("/admin_settings_user_crud/<page>", methods=["GET", "POST"])
@login_required
def admin_settings_user_crud(page):
    if request.method == "GET":
        if page == 'add':
            return render_template("admin_settings_user_add.html")
        elif page == 'edit':
            users_data = db.execute("SELECT id, uname, ufirst, ulast, uemail, is_admin FROM users")
            return render_template("admin_settings_user_edit.html", users_data=users_data)
        elif page == 'delete':
            return render_template("delete_user.html")
        else:
            return render_template("apology.html", message="incorrect choice")
    else:
        # value = int(page)
        if page == 'add':
            username = request.form.get("username")
            if not username:
                return render_template("apology.html", message="You must enter a Username")
            else:
                output = db.execute("SELECT id FROM users where uname=?", username)
                print(type(output))
                if (len(output) != 0 ):
                    return render_template("apology.html", message="Username already exists")
                firstname = request.form.get("firstname")
                lastname = request.form.get("lastname")
                email = request.form.get("email")
                password = request.form.get("password")
                confirmation = request.form.get("confirmation")
                email = request.form.get("email")
                if not firstname:
                    return render_template("apology.html", message="You must enter First Name")
                if not lastname:
                    return render_template("apology.html", message="You must enter Last Name")
                if not email:
                    return render_template("apology.html", message="You must enter a Email address")
                else:
                    output = db.execute("SELECT id FROM users where uemail=?", email)
                    print(type(output))
                    if (len(output) != 0 ):
                        return render_template("apology.html", message="Email already exists")
                password = request.form.get("password")
                if not password:
                    return render_template("apology.html", message="You must enter a Password")
                confirmation = request.form.get("confirmation")
                if not confirmation:
                    return render_template("apology.html", message="You must re-enter  Password")
                if password != confirmation:
                    return render_template("apology.html", message="Your passwoed does not match")
                else:
                    hash_password = generate_password_hash(password, method='pbkdf2:sha256', salt_length=8)
                    print(hash_password)
                    db.execute("INSERT INTO users (uname, ufirst, ulast , uemail, hash) VALUES (:uname, :ufirst, :ulast, :uemail, :hashvalue)", uname=username, ufirst=firstname, ulast=lastname, uemail=email, hashvalue=hash_password)
                    return redirect("/admin_settings_user")
        if page.isnumeric():
            print("inside edit user if")
            user_data = db.execute("SELECT uname, ufirst, ulast, uemail, is_admin FROM users where id=?",int(page))
            return render_template("edit_user.html",user_data=user_data,id=int(page))

@app.route("/edit_user/<id>", methods=["GET", "POST"])
@login_required
def edit_user(id):
    if request.method == "POST":
        uname= request.form.get("username")
        output = db.execute("SELECT id FROM users where uname=?", uname)
        print(type(output))
        if (len(output) != 0 ):
            return render_template("apology.html", message="Username already exists")
        
        firstname = request.form.get("firstname")
        lastname = request.form.get("lastname")
        email = request.form.get("email")
        password = request.form.get("password")
        confirmation = request.form.get("confirmation")
        email = request.form.get("email")
        if not firstname:
            return render_template("apology.html", message="You must enter First Name")
        if not lastname:
            return render_template("apology.html", message="You must enter Last Name")
        if not email:
            return render_template("apology.html", message="You must enter a Email address")
        else:
            output = db.execute("SELECT id FROM users where uemail=?", email)
            print(type(output))
            if (len(output) != 0 ):
                return render_template("apology.html", message="Email already exists")
            password = request.form.get("password")
            if not password:
                return render_template("apology.html", message="You must enter a Password")
            confirmation = request.form.get("confirmation")
            if not confirmation:
                return render_template("apology.html", message="You must re-enter  Password")
            if password != confirmation:
                return render_template("apology.html", message="Your passwoed does not match")
            else:
                hash_password = generate_password_hash(password, method='pbkdf2:sha256', salt_length=8)
                print(hash_password)
                db.execute("UPDATE  users set uname=?,ufirst=?,ulast=?,uemail=?, hash=? where id=?", uname,firstname, lastname, email, hash_password, id)
                return redirect("/admin_settings_user")

@app.route("/delete_user", methods=["GET", "POST"])
@login_required
def delete_user():
    if request.method == "GET":
        return render_template("delete_product.html")
    else:
        id = request.form.get("product_id")
        db.execute("DELETE FROM users where id=?", id)
        return redirect("/admin_settings_user")                

@app.route("/admin_settings_product_edit/<id>", methods=["GET", "POST"])
@login_required
def admin_settings_product_edit(id):
    if request.method == "GET":
        print(id)
        print(type(id))
        int_id = int(id)
        product_details = db.execute("SELECT id,pname, pprice, pdescription FROM product")
        if int_id != 0:
            product = db.execute("SELECT pname, pprice, pdescription FROM product where id=?", id)
            print(product)
            product_desc = product[0]['pdescription']
            return render_template("edit_product.html",id=id, product=product,product_desc=product_desc)
        return render_template("admin_settings_product_edit.html", product_details=product_details)
    else:
        pname = request.form.get("product_name")
        pprice = request.form.get("product_price")
        pimage = request.files["product_image"]
        pdescription = request.form.get("product_description")
        print(pname)
        print(pprice)
        # print(type(pimage))
        # print(pimage.filename)
        print(pdescription)
        if not pname:
            return render_template("apology.html", message="must enter product name")
        elif not pprice:
            return render_template("apology.html", message="must enter product price")
        elif not pimage:
            return render_template("apology.html", message="must upload product image")
        elif not pdescription:
            return render_template("apology.html", message="must enter product desciprtion")
        else:
            db.execute("UPDATE product set pname=?, pprice=?, pimage=?, pdescription=? where id =?",pname, pprice, pimage.read(), pdescription, id)
            return redirect("/admin_settings")
        
@app.route("/admin_settings_product_add", methods=["GET", "POST"])
@login_required
def admin_settings_product_add():
    if request.method == "GET":
        return render_template("admin_settings_product_add.html")
    else:
        pass
        # pname = request.form.get("product_name")
        # pprice = request.form.get("product_price")
        # pimage = request.files["product_image"]
        # pdescription = request.form.get("product_description")
        # print(pname)
        # print(pprice)
        # print(type(pimage))
        # print(pimage.filename)
        # print(pdescription)
        # if not pname:
        #     return render_template("apology.html", message="must enter product name")
        # elif not pprice:
        #     return render_template("apology.html", message="must enter product price")
        # elif not pimage:
        #     return render_template("apology.html", message="must upload product image")
        # elif not pdescription:
        #     return render_template("apology.html", message="must enter product desciprtion")
        # else:
        #     db.execute("INSERT INTO product (pname, pprice, pimage , pdescription) VALUES (:pname, :pprice, :pimage, :pdescription)", pname=pname, pprice=pprice, pimage=pimage.read(), pdescription=pdescription)
        #     return redirect("/admin_settings")


@app.route("/admin_settings_product_delete", methods=["GET", "POST"])
@login_required
def admin_settings_product_delete():
    if request.method == "GET":
        return render_template("delete_product.html")
    else:
        id = request.form.get("product_id")
        db.execute("DELETE FROM product where id=?", id)
        return redirect("/admin_settings")

@app.route("/buy_product/<id>", methods=["GET","POST"])
@login_required
def buy_product(id):
    if request.method == "GET":
        print("inside buy product")
        print(id)
        product_image = db.execute("SELECT pimage FROM product where id=?",id)
        product_name = db.execute("SELECT pname FROM product where id=?",id)
        product_price = db.execute("SELECT pprice FROM product where id=?",id)
        product_description = db.execute("SELECT pdescription FROM product where id=?",id)
        
        image = b64encode(product_image[0]['pimage']).decode("utf-8")
        
        return render_template("buy_product.html", id=id, image=image, product_name=product_name, product_price=product_price, product_description=product_description)
    else:
        print("inside post method")
        print(id)
        return render_template("buy_product.html", id=id)

# @app.route("/cart_page", methods=["GET", "POST"])
# @login_required
# def cart_page():
#     if request.method == "GET":
#         # print(id)
        
        
#         return render_template("checkout.html")
#     else:
#         print("inside post")
#         count = request.form.get("cart_items")
#         print(count)
#         db.execute("UPDATE users SET cart_items=? where id=?", count, session["user_id"])
#         return render_template("checkout.html",count=count)

@app.route("/buy/<id>", methods=["GET", "POST"])
@login_required
def buy(id):
    if request.method == "GET":
        print(id)
        product_image = db.execute("SELECT pimage FROM product where id=?",id)
        product_name = db.execute("SELECT pname FROM product where id=?",id)
        product_price = db.execute("SELECT pprice FROM product where id=?",id)
        image = b64encode(product_image[0]['pimage']).decode("utf-8")
        return render_template("checkout.html", id=id, image=image, product_name=product_name, product_price=product_price)
    else:
        print("inside post")
        pass



@app.route("/history", methods=["GET"])
@login_required
def history():
    if request.method == "GET":
        user_history = db.execute("SELECT uname, ufirst, ulast, uaddress, product_name, product_price FROM history where user_id=?", session["user_id"])
        return render_template("history.html", user_history=user_history)
    


@app.route("/settings", methods=["GET", "POST"])
@login_required
def settings():
    if request.method == "GET":
        return render_template("settings.html")
    else:
        # entered_password = request.form.get("currentpassword")
        rows = db.execute("SELECT * FROM users WHERE id=?", session['user_id'])
        if check_password_hash(rows[0]['hash'], request.form.get("currentpassword")):
            new_password = request.form.get("newpassword")
            check_password = request.form.get("checkpassword")
            if not new_password:
                return render_template("apology.html", message="You must enter a new Password")
            elif not check_password:
                return render_template("apology.html", message="You must re-enter Password")
            elif new_password != check_password:
                return render_template("apology.html", message="Your new password does not match")
            else:
                new_hash_password = generate_password_hash(new_password, method='pbkdf2:sha256', salt_length=8)
                db.execute("UPDATE users SET hash=? WHERE id=?", new_hash_password, session['user_id'])
                return redirect("/")

        else:
            return render_template("apology.html", message="password entered is wrong")



@app.route("/shipping/<id>", methods=["GET", "POST"])
@login_required
def invoice(id):
    if request.method == "GET":
        user_name = db.execute("SELECT uname FROM users where id=?", session["user_id"])
        user_first_name = db.execute("SELECT ufirst FROM users where id=?", session["user_id"])
        user_last_name = db.execute("SELECT ulast FROM users where id=?", session["user_id"])
        product_image = db.execute("SELECT pimage FROM product where id=?",id)
        product_name = db.execute("SELECT pname FROM product where id=?",id)
        product_price = db.execute("SELECT pprice FROM product where id=?",id)
        image = b64encode(product_image[0]['pimage']).decode("utf-8")
        return render_template("shipping.html", user_name=user_name,user_first_name=user_first_name,user_last_name=user_last_name, image=image, product_name=product_name, product_price=product_price, id=id)
    else:
        user_name = db.execute("SELECT uname FROM users where id=?", session["user_id"])
        user_first_name = db.execute("SELECT ufirst FROM users where id=?", session["user_id"])
        user_last_name = db.execute("SELECT ulast FROM users where id=?", session["user_id"])
        product_name = db.execute("SELECT pname FROM product where id=?",id)
        product_price = db.execute("SELECT pprice FROM product where id=?",id)
        address = request.form.get("address")
        ufirst = user_first_name[0]['ufirst']
        print(ufirst)
        if not address:
            return render_template("apology.html", message="please enter address")
        else:
            db.execute("INSERT INTO history (user_id, uname, ufirst , ulast, uaddress, product_name, product_price) VALUES (:user_id, :uname, :ufirst, :ulast, :uaddress,:product_name, :product_price)", user_id=session["user_id"], uname=user_name[0]['uname'], ufirst=ufirst, ulast=user_last_name[0]['ulast'], uaddress=address, product_name=product_name[0]['pname'], product_price=product_price[0]['pprice'])
            return render_template("thankyou.html")

